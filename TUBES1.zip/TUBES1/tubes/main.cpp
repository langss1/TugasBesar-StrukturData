#include <iostream>
#include "olim.h"

using namespace std;

int main()
{
    list_Atlet la;
    infotype_Atlet x;
    adr_Atlet a;
    int i, n;

    list_pertandingan lp;
    infotype_pertandingan y;
    adr_pertandingan p;

    createList_Atlet(la);
    createList_pertandingan(lp);

    string kembali;
    int pilih = -1;  // Memastikan pilih tidak langsung 0
    while(pilih != 0) {
        cout << "=======ATLET BADMINTON TUNGGAL PUTRA OLIMPIADE PARIS 2024========" << endl;
        cout << "1. Input Data Atlet" << endl;
        cout << "2. Input Data pertandingan" << endl;
        cout << "3. Tampilkan Semua Data Atlet" << endl;
        cout << "4. Tampilkan Semua Data pertandingan" << endl;
        cout << "5. Hapus Data Atlet" << endl;
        cout << "6. Hapus Data Pertandingan" << endl;
        cout << "0. Exit" << endl;
        cout << "Pilih menu: ";
        cin >> pilih;
        cout << endl;

        if (pilih == 1) {
            cout << "Banyak list Atlet yang ingin dimasukkan: ";
            cin >> n;
            i = 1;
            while(i <= n) {
                cout << "Data ke-" << i << endl;
                cout << "Masukan nama Atlet  : ";
                cin >> x.nama;
                cout << "Masukan usia Atlet  : ";
                cin >> x.usia;
                cout << "Masukan ID Atlet    : ";
                cin >> x.ID;
                cout << "Masukan negara Atlet: ";
                cin >> x.negara;
                cout << "Masukan Rank Atlet  : ";
                cin >> x.rank;
                a = createelemen_Atlet(x);
                insert_Atlet(la, a);
                i++;
            }
            cout << endl;

            //kembali ke menu utama
            cout << "Kembali ke menu utama? (Y/N) : ";
            cin >> kembali;
            if (kembali == "N") {
                pilih = 0; // Mengubah pilih menjadi 0 untuk keluar dari loop
            }
            cout << endl;

        } else if(pilih == 2) {
            cout << "Banyak list pertandingan yang ingin dimasukkan: ";
            cin >> n;
            for(i = 0; i < n; i++) {
                cout << "Data ke-" << i+1 << endl;
                cout << "Masukan round pertandingan: ";
                cin >> y.round;
                cout << "Masukan nama wasit        : ";
                cin >> y.wasit;
                cout << "Masukan venue pertandingan: ";
                cin >> y.venue;
                cout << "Masukan hari & tanggal    : ";
                cin >> y.hari_tgl;
                cout << "Masukan jumlah penonton   : ";
                cin >> y.penonton;
                p = createElemen_pertandingan(y);
                insert_pertandingan(lp, p);
            }
            cout << endl;

            cout << "Kembali ke menu utama? (Y/N) : ";
            cin >> kembali;
            if (kembali == "N") {
                pilih = 0; // Mengubah pilih menjadi 0 untuk keluar dari loop
            }
            cout << endl;

        } else if (pilih == 3) {
            show_All_Atlet(la);

            cout << "Kembali ke menu utama? (Y/N) : ";
            cin >> kembali;
            if (kembali == "N") {
                pilih = 0; // Mengubah pilih menjadi 0 untuk keluar dari loop
            }
            cout << endl;

        } else if(pilih == 4) {
            show_All_pertandingan(lp);

            cout << "Kembali ke menu utama? (Y/N) : ";
            cin >> kembali;
            if (kembali == "N") {
                pilih = 0; // Mengubah pilih menjadi 0 untuk keluar dari loop
            }
            cout << endl;

        }   else if (pilih == 5) {
            string id;
            cout << "Masukkan ID Atlet yang ingin dihapus: ";
            cin >> id;
            delete_Atlet(la, id);

            cout << "Kembali ke menu utama? (Y/N) : ";
            cin >> kembali;
            if (kembali == "N") {
                pilih = 0;
            }
            cout << endl;

        } else if (pilih == 6) {
            string round;
            cout << "Masukkan round pertandingan yang ingin dihapus: ";
            cin >> round;
            delete_pertandingan(lp, round);

            cout << "Kembali ke menu utama? (Y/N) : ";
            cin >> kembali;
            if (kembali == "N") {
                pilih = 0;
            }
            cout << endl;

        } else if(pilih == 0) {
            // Pesan ini akan ditampilkan ketika pilih = 0 untuk keluar dari loop
            cout << "ANDA TELAH KELUAR DARI PROGRAM" << endl;
        }
    }
    cout << "ANDA TELAH KELUAR DARI PROGRAM" << endl;

    return 0;
}
