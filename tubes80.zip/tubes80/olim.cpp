#include <iostream>
#include "olim.h"

using namespace std;

/*
-----------------------------------------  BAGIAN MENU -----------------------------------------
*/

int menu(){
        int pilih;
        cout << "=======MENU ATLET BADMINTON TUNGGAL PUTRA OLIMPIADE PARIS 2024========" << endl;
        cout << "1. Input Data Atlet" << endl;
        cout << "2. Input Data pertandingan" << endl;
        cout << "3. Tampilkan Semua Data Atlet" << endl;
        cout << "4. Tampilkan Semua Data pertandingan" << endl;
        cout << "5. Hapus Data Atlet" << endl;
        cout << "6. Hapus Data Pertandingan" << endl;
        cout << "7. Input Relasi" << endl;
        cout << "8. Show data Relasi atlet Badminton" << endl;
        cout << "9. Find elemen relation" << endl;
        cout << "10. Show data dari pertandingan tertentu" << endl;
        cout << "11. Hitung jumlah atlet dari suatu pertandingan" << endl;
        cout << "12. Edit pertandingan dari atlet badminton" << endl;
        cout << "0. Exit" << endl;
        cout << "Pilih menu: ";
        cin >> pilih;

        return pilih;
}

void menu_input_data_atlet(list_Atlet &la, int &pilih){
            infotype_Atlet x;
            adr_Atlet a;
            int i, n;

            string kembali;
            cout << "Banyak list Atlet yang ingin dimasukkan: ";
            cin >> n;
            i = 1;
            while(i <= n) {
                cout << "Data ke-" << i << endl;
                cout << "Masukan nama Atlet  : ";
                cin >> x.nama;
                cout << "Masukan usia Atlet  : ";
                cin >> x.usia;
                cout << "Masukan ID Atlet    : ";
                cin >> x.ID;
                cout << "Masukan negara Atlet: ";
                cin >> x.negara;
                cout << "Masukan Rank Atlet  : ";
                cin >> x.rank;
                adr_Atlet z = find_atlet(la, x.ID);
                if (z == NULL){
                    a = createelemen_Atlet(x);
                    insert_Atlet(la, a);
                    i++;
                } else {
                    cout << "Input gagal, ID sudah terdaftar, silahkan ulangi" << endl;
                }
            }
            cout << endl;

            //kembali ke menu utama
            cout << "Kembali ke menu utama? (Y/N) : ";
            cin >> kembali;
            if (kembali == "N") {
                pilih = 0; // Mengubah pilih menjadi 0 untuk keluar dari loop
            }
            cout << endl;
}

void menu_input_data_pertandingan(list_pertandingan &lp, int &pilih){
    infotype_pertandingan y;
    adr_pertandingan p;
    int i, n;

    string kembali;
    cout << "Banyak list pertandingan yang ingin dimasukkan: ";
            cin >> n;
            for(i = 0; i < n; i++) {
                cout << "Data ke-" << i+1 << endl;
                cout << "Masukan round pertandingan: ";
                cin >> y.round;
                cout << "Masukan nama wasit        : ";
                cin >> y.wasit;
                cout << "Masukan venue pertandingan: ";
                cin >> y.venue;
                cout << "Masukan hari & tanggal    : ";
                cin >> y.hari_tgl;
                cout << "Masukan jumlah penonton   : ";
                cin >> y.penonton;
                p = createElemen_pertandingan(y);
                insert_pertandingan(lp, p);
            }
            cout << endl;

            cout << "Kembali ke menu utama? (Y/N) : ";
            cin >> kembali;
            if (kembali == "N") {
                pilih = 0; // Mengubah pilih menjadi 0 untuk keluar dari loop
            }
            cout << endl;
}

void menu_show_data_atlet(list_Atlet la, int &pilih){
            string kembali;
            show_All_Atlet(la);

            cout << "Kembali ke menu utama? (Y/N) : ";
            cin >> kembali;
            if (kembali == "N") {
                pilih = 0; // Mengubah pilih menjadi 0 untuk keluar dari loop
            }
            cout << endl;
}
void menu_show_data_pertandingan(list_pertandingan &lp, int &pilih){
    show_All_pertandingan(lp);

            string kembali;
            cout << "Kembali ke menu utama? (Y/N) : ";
            cin >> kembali;
            if (kembali == "N") {
                pilih = 0; // Mengubah pilih menjadi 0 untuk keluar dari loop
            }
            cout << endl;
}
void menu_delete_atlet(list_Atlet &la, int &pilih){
            string kembali;
            string id;
            cout << "Masukkan ID Atlet yang ingin dihapus: ";
            cin >> id;
            delete_Atlet(la, id);

            cout << "Kembali ke menu utama? (Y/N) : ";
            cin >> kembali;
            if (kembali == "N") {
                pilih = 0;
            }
            cout << endl;
}
void menu_delete_pertandingan(list_pertandingan &lp, int &pilih){
    string round;
    string kembali;
            cout << "Masukkan round pertandingan yang ingin dihapus: ";
            cin >> round;
            delete_pertandingan(lp, round);

            cout << "Kembali ke menu utama? (Y/N) : ";
            cin >> kembali;
            if (kembali == "N") {
                pilih = 0;
            }
            cout << endl;
}

void menu_relasi(list_relasi &lr, list_Atlet la, list_pertandingan lp, int &pilih){
    string id, round;
    cout << "Masukan ID Atlet: ";
    cin >> id;

    cout << "Masukan Round Pertandingan: ";
    cin >> round;

    adr_Atlet p = find_atlet(la, id);
    adr_pertandingan q = find_pertandingan(lp, round);

    if (p != NULL && q != NULL){
        insert_relasi(lr, p, q);
    } else {
        cout << "Pemasukan tidak berhasil sebab, salah satu elemen salah" << endl;
    }

    string kembali;
    cout << "Kembali ke menu utama? (Y/N) : ";
    cin >> kembali;
    if (kembali == "N") {
        pilih = 0;
    }
    cout << endl;
}

void menu_show_relasi_atlet(list_relasi lr, int &pilih){
    show_relasi_atlet(lr);

            string kembali;
            cout << "Kembali ke menu utama? (Y/N) : ";
            cin >> kembali;
            if (kembali == "N") {
                pilih = 0; // Mengubah pilih menjadi 0 untuk keluar dari loop
            }
            cout << endl;
}

void menu_find_relasi(list_relasi lr, int &pilih){

    string id, round;

    cout << "Cari Atlet: ";
    cin >> id;

    cout << "Cari Round: ";
    cin >> round;

    cout << "Relasi ID atlet " << id << " Antara " << round << ": " << find_relasi(lr, id, round);

    string kembali;
        cout << "Kembali ke menu utama? (Y/N) : ";
        cin >> kembali;
            if (kembali == "N") {
                pilih = 0; // Mengubah pilih menjadi 0 untuk keluar dari loop
            }
            cout << endl;
}

void menu_show_data_pertandingan_atlet(list_relasi lr, int &pilih){
     string id;
     cout << "Masukan ID atlet: ";
     cin >> id;

     show_pertandingan_dari_atlet(lr, id);
       string kembali;
        cout << "Kembali ke menu utama? (Y/N) : ";
        cin >> kembali;
            if (kembali == "N") {
                pilih = 0; // Mengubah pilih menjadi 0 untuk keluar dari loop
            }
            cout << endl;
}

void menu_count_atlet_dari_pertandingan(list_relasi lr, int &pilih){
    string round;
    cout << "Round Berapa: ";
    cin >> round;
    cout << "Jumlah Atlet dari suatu pertandingan: " << jumlah_atlet_dari_pertandingan(lr, round) << endl;
    string kembali;
        cout << "Kembali ke menu utama? (Y/N) : ";
        cin >> kembali;
            if (kembali == "N") {
                pilih = 0; // Mengubah pilih menjadi 0 untuk keluar dari loop
            }
            cout << endl;
}

void menu_edit_relasi(list_relasi &lr, int &pilih){
    string id, round_s, round_j;

    cout << "Masukan ID: ";
    cin >> id;

    cout << "Masukan Round Sebelumnya: ";
    cin >> round_s;

    cout << "Masukan Round Selanjutnya: ";
    cin >> round_j;
    edit_relasi(lr, id, round_s, round_j);
}


/*
-----------------------------------------  BAGIAN INSERT -----------------------------------------
*/


//add atlet
void createList_Atlet(list_Atlet &la){
    la.first = NULL;
    la.last = NULL;
}

adr_Atlet createelemen_Atlet(infotype_Atlet x){
    adr_Atlet p = new elemen_Atlet;
    p -> info = x;
    p -> next = NULL;
    p -> prev = NULL;
    return p;
}

void insert_Atlet(list_Atlet &la, adr_Atlet p){
    if (la.first == NULL && la.last == NULL){
        la.first = p;
        la.last = p;
    } else {
        p -> prev = la.last;
        p -> prev -> next = p;
        la.last = p;
    }
}

// add pertandingan
void createList_pertandingan(list_pertandingan &lp){
    lp.first = NULL;
}

adr_pertandingan createElemen_pertandingan(infotype_pertandingan x){
    adr_pertandingan p = new elemen_pertandingan;
    p->info = x;
    p->next = NULL;

    return p;
}

void insert_pertandingan(list_pertandingan &lp, adr_pertandingan p){
    if(lp.first == NULL){
        lp.first = p;
    }else{
        adr_pertandingan q = lp.first;
        while(q->next != NULL){
            q = q->next;
        }
        q->next = p;
    }
}

//add relasi
void createlist_relasi(list_relasi &lr){
    lr.first = NULL;
}

adr_relasi createElemen_relasi(adr_Atlet p, adr_pertandingan q){
    adr_relasi z = new elemen_relasi;
    z ->atlet = p;
    z ->next = NULL;
    z ->pertandingan = q;
    return z;
}

void insert_relasi(list_relasi &lr, adr_Atlet p, adr_pertandingan q){
    adr_relasi z = createElemen_relasi(p, q);
    if(lr.first == NULL){
        lr.first = z;
    } else {
        adr_relasi a = lr.first;
        while(a -> next != NULL){
            a = a -> next;
        }
        a -> next = z;
    }
}

/*
-----------------------------------------  BAGIAN PRINT -----------------------------------------
*/


//print data atlet
void show_All_Atlet(list_Atlet la){
    adr_Atlet p = la.first;

    cout << "==================== Print List Atlet ==================== " << endl;
    cout << endl;
    while(p != NULL){
        cout << "Nama Atlet  : " << p -> info.nama << endl;
        cout << "Negara Atlet: " << p -> info.negara << endl;
        cout << "ID Atlet    : " << p -> info.ID << endl;
        cout << "Usia Atlet  : " << p -> info.usia << endl;
        cout << "Rank Atlet  : " << p -> info.rank << endl;
        cout << endl;

        p = p -> next;
    }
}

// show data pertandingan
void show_All_pertandingan(list_pertandingan lp){
    adr_pertandingan p = lp.first;

    cout << "==================== Print List Atlet ==================== " << endl;
    cout << endl;
    while(p != NULL){
        cout << "Round          : " << p->info.round << endl;
        cout << "Wasit          : " << p->info.wasit << endl;
        cout << "Vanue          : " << p->info.venue << endl;
        cout << "Hari & Tanggal : " << p->info.hari_tgl << endl;
        cout << "Penonton       : " << p->info.penonton << endl;
        cout << endl;

        p = p->next;
    }
}

void show_relasi_atlet(list_relasi lr){
    adr_relasi p = lr.first;
    while (p != NULL){
        cout << p ->atlet -> info.nama << endl;
        cout << p ->pertandingan -> info.round << endl;
        cout << "============================" << endl;
        p = p ->next;
    }
}

//print data dari suatu atlet
void show_pertandingan_dari_atlet(list_relasi lr, string id){
    adr_relasi p = lr.first;
    cout << "data pertandingan dari suatu atlet: " << id << endl;
    while(p != NULL){
        if (p ->atlet->info.ID == id){
            cout << p ->pertandingan ->info.round<< endl;
        }
        p = p -> next;
    }
}

/*
-----------------------------------------  BAGIAN DELETE -----------------------------------------
*/



//delete atlet
void delete_Atlet(list_Atlet &la, string id) {
    adr_Atlet p = la.first;

    while (p != NULL && p->info.ID != id) {
        p = p->next;
    }

    if (p == NULL) {
        cout << "Atlet dengan ID " << id << " tidak ditemukan." << endl;
    } else {
        if (p == la.first && p == la.last) {
            la.first = NULL;
            la.last = NULL;
        } else if (p == la.first) {
            la.first = p->next;
            la.first->prev = NULL;
        } else if (p == la.last) {
            la.last = p->prev;
            la.last->next = NULL;
        } else {
            p->prev->next = p->next;
            p->next->prev = p->prev;
        }
        delete p;
        cout << "Atlet dengan ID " << id << " berhasil dihapus." << endl;
    }
}

// delete pertandingan
void delete_pertandingan(list_pertandingan &lp, string round) {
    adr_pertandingan p = lp.first;
    adr_pertandingan q = NULL;

    while (p != NULL && p->info.round != round) {
        q = p;
        p = p->next;
    }

    if (p == NULL) {
        cout << "Pertandingan dengan round " << round << " tidak ditemukan." << endl;
    } else {
        if (p == lp.first) {
            lp.first = p->next;
        } else {
            q->next = p->next;
        }
        delete p;
        cout << "Pertandingan dengan round " << round << " berhasil dihapus." << endl;
    }
}

/*
-----------------------------------------  BAGIAN FIND -----------------------------------------
*/

//find atlet_badminton
adr_Atlet find_atlet(list_Atlet la, string id){
    adr_Atlet p = la.first;
    while(p != NULL){
        if (p ->info.ID == id){
            return p;
        }
        p = p ->next;
    }
    return NULL;
}


//find pertandingan
adr_pertandingan find_pertandingan(list_pertandingan lp, string round){
    adr_pertandingan p = lp.first;
    while(p != NULL){
        if (p ->info.round == round){
            return p;
        }
        p = p ->next;
    }
    return NULL;
}

//find relasi
adr_relasi find_relasi(list_relasi lr, string id, string round){
    bool check = false;
    adr_relasi p = lr.first;

    while(p != NULL && !check){
            if (p ->atlet ->info.ID == id && p ->pertandingan ->info.round == round){
                return p;
            }
            p = p ->next;
    }

    return NULL;
}

/*
-----------------------------------------  BAGIAN COUNT -----------------------------------------
*/

//count jumlah atlet dari suatu pertandingan
int jumlah_atlet_dari_pertandingan(list_relasi lr, string round){
    adr_relasi p = lr.first;
    int jumlah = 0;
    while(p != NULL){
        if (p ->pertandingan ->info.round == round){
            jumlah ++;
        }
        p = p -> next;
    }
    return jumlah;
}

/*
-----------------------------------------  BAGIAN EDIT -----------------------------------------
*/

//edit
void edit_relasi(list_relasi &lr, string id, string round_sebelumnya, string round_selanjutnya){
    adr_relasi p = find_relasi(lr, id, round_sebelumnya);
    p ->pertandingan->info.round = round_selanjutnya;
}
