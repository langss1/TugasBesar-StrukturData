#ifndef OLIM_H_INCLUDED
#define OLIM_H_INCLUDED

using namespace std;

struct atlet_badminton{
    string nama, negara, ID;
    int usia, rank;
};

typedef atlet_badminton infotype_Atlet;

struct pertandingan{
    string round, wasit, venue, hari_tgl;
    int penonton;
};

typedef pertandingan infotype_pertandingan;

typedef struct elemen_Atlet *adr_Atlet;
typedef struct elemen_relasi *adr_relasi;
typedef struct elemen_pertandingan *adr_pertandingan;

struct elemen_Atlet {
    infotype_Atlet info;
    adr_Atlet next;
    adr_Atlet prev;
};

struct elemen_pertandingan{
    infotype_pertandingan info;
    adr_pertandingan next;
};

struct elemen_relasi{
    adr_Atlet atlet;
    adr_pertandingan pertandingan;
    adr_relasi next;
};

struct list_Atlet{
    adr_Atlet first;
    adr_Atlet last;
};

struct list_pertandingan{
    adr_pertandingan first;
};

struct list_relasi{
    adr_relasi first;
};

/*
-----------------------------------------  BAGIAN MENU -----------------------------------------
*/
int menu();
void menu_input_data_atlet(list_Atlet &la, int &pilih);
void menu_input_data_pertandingan(list_pertandingan &lp, int &pilih);
void menu_show_data_atlet(list_Atlet la, int &pilih);
void menu_show_data_pertandingan(list_pertandingan &lp, int &pilih);
void menu_delete_atlet(list_Atlet &la, int &pilih);
void menu_delete_pertandingan(list_pertandingan &lp, int &pilih);
void menu_relasi(list_relasi &lr, list_Atlet la, list_pertandingan lp, int &pilih);
void menu_show_relasi_atlet(list_relasi lr, int &pilih);
void menu_find_relasi(list_relasi lr, int &pilih);

void menu_show_data_pertandingan_atlet(list_relasi lr, int &pilih);
void menu_count_atlet_dari_pertandingan(list_relasi lr, int &pilih);
void menu_edit_relasi(list_relasi &lr, int &pilih);


/*
-----------------------------------------  BAGIAN INSERT -----------------------------------------
*/

//add atlet
void createList_Atlet(list_Atlet &la);
adr_Atlet createelemen_Atlet(infotype_Atlet x);
void insert_Atlet(list_Atlet &la, adr_Atlet p);

// add pertandingan
void createList_pertandingan(list_pertandingan &lp);
adr_pertandingan createElemen_pertandingan(infotype_pertandingan x);
void insert_pertandingan(list_pertandingan &lp, adr_pertandingan p);

//add relasi
void createlist_relasi(list_relasi &lr);
adr_relasi createElemen_relasi(adr_Atlet p, adr_pertandingan q);
void insert_relasi(list_relasi &lr, adr_Atlet p, adr_pertandingan q);

/*
-----------------------------------------  BAGIAN PRINT -----------------------------------------
*/

//print data atlet
void show_All_Atlet(list_Atlet la);

//print data pertandingan
void show_All_pertandingan(list_pertandingan lp);

//print data relasi atlet
void show_relasi_atlet(list_relasi lr);

//print data dari suatu atlet
void show_pertandingan_dari_atlet(list_relasi lr, string id);

/*
-----------------------------------------  BAGIAN DELETE -----------------------------------------
*/

//delete data atlet
void delete_Atlet(list_Atlet &la, string id);

//delete data pertandingan
void delete_pertandingan(list_pertandingan &lp, string round);

/*
-----------------------------------------  BAGIAN FIND -----------------------------------------
*/

//find atlet_badminton
adr_Atlet find_atlet(list_Atlet la, string id);

//find pertandingam
adr_pertandingan find_pertandingan(list_pertandingan lp, string round);

//find relasi
adr_relasi find_relasi(list_relasi lr, string id, string round);

/*
-----------------------------------------  BAGIAN COUNT -----------------------------------------
*/

//count jumlah atlet dari suatu pertandingan
int jumlah_atlet_dari_pertandingan(list_relasi lr, string round);

/*
-----------------------------------------  BAGIAN EDIT -----------------------------------------
*/

//edit
void edit_relasi(list_relasi &lr, string id, string round_sebelumnya, string round_selanjutnya);

#endif // OLIM_H_INCLUDED

