#include <iostream>
#include "olim.h"

using namespace std;

int main()
{
    list_Atlet la;
    list_pertandingan lp;
    list_relasi lr;

    createList_Atlet(la);
    createList_pertandingan(lp);
    createlist_relasi(lr);


    string kembali;
    int pilih = -1;  // Memastikan pilih tidak langsung 0
    while(pilih != 0) {
        pilih = menu();
        cout << endl;

        if (pilih == 1) {
            menu_input_data_atlet(la, pilih);
        } else if(pilih == 2) {
            menu_input_data_pertandingan(lp, pilih);

        } else if (pilih == 3) {
            menu_show_data_atlet(la, pilih);

        } else if(pilih == 4) {
            menu_show_data_pertandingan(lp, pilih);

        } else if (pilih == 5) {
            menu_delete_atlet(la, pilih);

        } else if (pilih == 6) {
            menu_delete_pertandingan(lp, pilih);

        } else if (pilih == 7) {
            menu_relasi(lr, la, lp, pilih);

        } else if (pilih == 8) {
            menu_show_relasi_atlet(lr, pilih);

        } else if (pilih == 9) {
            menu_find_relasi(lr, pilih);

        }  else if (pilih == 10) {
            menu_show_data_pertandingan_atlet(lr, pilih);

        } else if (pilih == 11) {
            menu_count_atlet_dari_pertandingan(lr, pilih);

        } else if (pilih == 12) {
            menu_edit_relasi(lr, pilih);
        }


    }
    cout << "ANDA TELAH KELUAR DARI PROGRAM" << endl;

    return 0;
}
