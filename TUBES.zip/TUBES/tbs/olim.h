#ifndef OLIM_H_INCLUDED
#define OLIM_H_INCLUDED

using namespace std;

struct atlet_badminton{
    string nama, negara, ID;
    int usia, rank;
};

typedef atlet_badminton infotype_Atlet;

struct pertandingan{
    string round, wasit, venue, hari_tgl;
    int penonton;
};

typedef pertandingan infotype_pertandingan;

typedef struct elemen_Atlet *adr_Atlet;
typedef struct elemen_pertandingan *adr_pertandingan;

struct elemen_Atlet {
    infotype_Atlet info;
    adr_Atlet next;
    adr_Atlet prev;
};

struct elemen_pertandingan{
    infotype_pertandingan info;
    adr_pertandingan next;
};

struct list_Atlet{
    adr_Atlet first;
    adr_Atlet last;
};

struct list_pertandingan{
    adr_pertandingan first;
};

//add atlet
void createList_Atlet(list_Atlet &la);
adr_Atlet createelemen_Atlet(infotype_Atlet x);
void insert_Atlet(list_Atlet &la, adr_Atlet p);

// add pertandingan
void createList_pertandingan(list_pertandingan &lp);
adr_pertandingan createElemen_pertandingan(infotype_pertandingan x);
void insert_pertandingan(list_pertandingan &lp, adr_pertandingan p);

//print data atlet
void show_All_Atlet(list_Atlet la);

//print data pertandingan
void show_All_pertandingan(list_pertandingan lp);

#endif // OLIM_H_INCLUDED
