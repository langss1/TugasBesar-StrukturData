#include <iostream>
#include "olim.h"

using namespace std;

//add atlet
void createList_Atlet(list_Atlet &la){
    la.first = NULL;
    la.last = NULL;
}

adr_Atlet createelemen_Atlet(infotype_Atlet x){
    adr_Atlet p = new elemen_Atlet;
    p -> info = x;
    p -> next = NULL;
    p -> prev = NULL;
    return p;
}

void insert_Atlet(list_Atlet &la, adr_Atlet p){
    if (la.first == NULL && la.last == NULL){
        la.first = p;
        la.last = p;
    } else {
        p -> prev = la.last;
        p -> prev -> next = p;
        la.last = p;
    }
}

// add pertandingan
void createList_pertandingan(list_pertandingan &lp){
    lp.first = NULL;
}

adr_pertandingan createElemen_pertandingan(infotype_pertandingan x){
    adr_pertandingan p = new elemen_pertandingan;
    p->info = x;
    p->next = NULL;

    return p;
}

void insert_pertandingan(list_pertandingan &lp, adr_pertandingan p){
    if(lp.first == NULL){
        lp.first = p;
    }else{
        adr_pertandingan q = lp.first;
        while(q->next != NULL){
            q = q->next;
        }
        q->next = p;
    }
}

//print data atlet
void show_All_Atlet(list_Atlet la){
    adr_Atlet p = la.first;

    cout << "==================== Print List Atlet ==================== " << endl;
    cout << endl;
    while(p != NULL){
        cout << "Nama Atlet  : " << p -> info.nama << endl;
        cout << "Negara Atlet: " << p -> info.negara << endl;
        cout << "ID Atlet    : " << p -> info.ID << endl;
        cout << "Usia Atlet  : " << p -> info.usia << endl;
        cout << "Rank Atlet  : " << p -> info.rank << endl;
        cout << endl;

        p = p -> next;
    }
}

// show data pertandingan
void show_All_pertandingan(list_pertandingan lp){
    adr_pertandingan p = lp.first;

    cout << "==================== Print List Atlet ==================== " << endl;
    cout << endl;
    while(p != NULL){
        cout << "Round          : " << p->info.round << endl;
        cout << "Wasit          : " << p->info.wasit << endl;
        cout << "Vanue          : " << p->info.venue << endl;
        cout << "Hari & Tanggal : " << p->info.hari_tgl << endl;
        cout << "Penonton       : " << p->info.penonton << endl;
        cout << endl;

        p = p->next;
    }
}

