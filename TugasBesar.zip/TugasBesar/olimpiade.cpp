#include <iostream>
#include "olimpiade.h"

using namespace std;

//add atlet
void createList_Atlet(list_Atlet &la){
    la.first = NULL;
    la.last = NULL;
}

adr_Atlet createelemen_Atlet(infotype_Atlet x){
    adr_Atlet p = new elemen_Atlet;
    p -> info = x;
    p -> next = NULL;
    p -> prev = NULL;
    return p;
}

void insert_Atlet(list_Atlet &la, adr_Atlet p){
    if (la.first == NULL && la.last == NULL){
        la.first = p;
        la.last = p;
    } else {
        p -> prev = la.last;
        p -> prev -> next = p;
        la.last = p;
    }
}

//print data atlet
void show_All_Atlet(list_Atlet la){
    adr_Atlet p = la.first;

    cout << "==================== Print List Atlet ==================== " << endl;
    cout << endl;
    while(p != NULL){
        cout << "Nama Atlet: " << p -> info.nama << endl;
        cout << "Negara Atlet: " << p -> info.negara << endl;
        cout << "ID Atlet: " << p -> info.ID << endl;
        cout << "Usia Atlet: " << p -> info.usia << endl;
        cout << "Rank Atlet: " << p -> info.rank << endl;
        cout << endl;

        p = p -> next;
    }
}
