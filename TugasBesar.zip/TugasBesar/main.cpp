#include <iostream>
#include "olimpiade.h"

using namespace std;

int main()
{
   // nanti tambahin aja sesuai kebutuhgan

   list_Atlet la;
   infotype_Atlet x;
   adr_Atlet p;
   int i, n;
   i = 1;

   createList_Atlet(la);
   cout << "Masukan banyaknya list atlet: ";
   cin >> n;

   while(i <= n){
    cout << "Masukan nama Atlet: ";
    cin >> x.nama;
    cout << "Masukan usia Atlet: ";
    cin >> x.usia;
    cout << "Masukan ID Atlet: ";
    cin >> x.ID;
    cout << "Masukan negara Atlet: ";
    cin >> x.negara;
    cout << "Masukan Rank Atlet: ";
    cin >> x.rank;
    p = createelemen_Atlet(x);
    insert_Atlet(la, p);

    i ++;
   }

   cout << endl;

   show_All_Atlet(la);




}
