#ifndef OLIMPIADE_H_INCLUDED
#define OLIMPIADE_H_INCLUDED

using namespace std;

struct atlet_badminton{
    string nama, negara, ID;
    int usia, rank;
};

//nanti tambahin aja headernya sesuai keperluannya

typedef atlet_badminton infotype_Atlet;
typedef struct elemen_Atlet *adr_Atlet;

struct elemen_Atlet {
    infotype_Atlet info;
    adr_Atlet next;
    adr_Atlet prev;
};

struct list_Atlet{
    adr_Atlet first;
    adr_Atlet last;
};

//add atlet
void createList_Atlet(list_Atlet &la);
adr_Atlet createelemen_Atlet(infotype_Atlet x);
void insert_Atlet(list_Atlet &la, adr_Atlet p);

//print data atlet
void show_All_Atlet(list_Atlet la);



#endif // OLIMPIADE_H_INCLUDED
